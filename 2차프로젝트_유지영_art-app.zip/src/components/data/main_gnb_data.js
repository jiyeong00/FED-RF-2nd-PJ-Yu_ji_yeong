//  GNB메뉴 데이터 ////

export default {
  메뉴: [
    "Oil Colors",
    "Korean Colors",
    "Gouache",
    "Poster Colors",
  ],
  회원가입:[
    "로그인",
    "회원가입",
    "위시리스트",
  ],
 
};
