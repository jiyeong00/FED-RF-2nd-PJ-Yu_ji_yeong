import { createContext } from "react";

export const aCon = createContext();
export const bCon = createContext();