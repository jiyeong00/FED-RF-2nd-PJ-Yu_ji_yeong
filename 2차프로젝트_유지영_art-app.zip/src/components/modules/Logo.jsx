// DC.com 로고 컴포넌트
import React from "react";

// 이미지 경로 데이터 불러오기

export default function Logo() {
  // logoStyle : 상단, 하단 로고 구분 코드

  return (
      <img src={process.env.PUBLIC_URL+"/img/logo_b.png"} alt="신한화구 로고이미지" />
  );
} ///////////Logo.////////////////
